<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> PRODOTTO 2 </title>
    </head>
    
    <body class="background">
        <hr class="rigaone">
        <hr class="rigatwo">
        <hr class="rigathree">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>
        <div class="rigasxaz">ROMANI&CO</div>

        <div class="produd">
            <img src="img\lancia.jpg" class="imgprodu">
            <div class="tprodu">
            La lancia romana, o hasta, era un'arma da lancio o da combattimento ravvicinato utilizzata dai legionari. 
            Consisteva in un'asta di legno, generalmente lunga 2-3 metri, con una punta metallica affilata. 
            Era robusta e versatile, usata sia per colpire a distanza che per sfondare le difese nemiche durante le battaglie.
            </div>
        </div>

        <button class="btprodu"> Acquista ora </button>
        
    </body>
    
</html>