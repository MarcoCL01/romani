<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> EXPLORE </title>
    </head>
    
    <body class="background">
        <hr class="rigaone">
        <hr class="rigatwo">
        <hr class="rigathree">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>
        <div class="rigasxaz">ROMANI&CO</div>
        <div class="imgsxex"> <img src="img\stemma2.png" class="imagesxrom"> </div>
        <div class="imgdxex"> <img src="img\stemma2.png" class="imagedxrom"> </div>

        <div class="titex">INFORMAZIONI AGGIUNTIVE</div>

        <div class="testoex">Questa area di testo, è a vostra disposizione per informazioni aggiuntive<br>riguardante l'argomento dei vari progetti,<br>
        o per disposizioni e idee ulteriori riguardanti il nostro sito.
        </div>
        
        <textarea id="textex" class="areat" placeholder="Scrivi qui..."></textarea>
        <input type="submit" class="inviaex" id="inviaex"  value="Invia">

    <script src="assets/js/script.js" defer></script>     
    </body>
    
</html>

