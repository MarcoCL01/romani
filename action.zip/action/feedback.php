<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> CONTATTI AZIENDALI </title>
    </head>
    
    <body class="background">
    <hr class="rigaconto">
    <hr class="rigacontt">
    <hr class="rigaconttt">
    <hr class="rigacontf">
    <hr class="rigacontff">
    <hr class="rigaconts">
    <div class="rigabsx">ROMANI&CO</div>
    <div class="rigabdx">ROMANI&CO</div>

    <div class="contaifeed">
        <div class="testofeedu">FEEDBACK RIGUARDANTI IL NOSTRO SITO</div>
        <div class="testofeedt"> LIVELLO DI CONTENUTI : </div>
        <div class="stelval">
            <input class="stel" type="radio" value="5" id="star5" name="valut">
            <label class="stelabel" for="star5">★</label>
            <input class="stel" type="radio" value="4" id="star4" name="valut">
            <label class="stelabel" for="star4">★</label>
            <input class="stel" type="radio" value="3" id="star3" name="valut">
            <label class="stelabel" for="star3">★</label>
            <input class="stel" type="radio" value="2" id="star2" name="valut">
            <label class="stelabel" for="star2">★</label>
            <input class="stel" type="radio" value="1" id="star1" name="valut">
            <label class="stelabel" for="star1">★</label>
        </div>
        <div class="testofeedtt"> LIVELLO DI ACCESSIBILITA' : </div>
        <div class="stelvalt">
            <input class="stel" type="radio" value="5" id="star52" name="valut2">
            <label class="stelabel" for="star52">★</label>
            <input class="stel" type="radio" value="4" id="star42" name="valut2">
            <label class="stelabel" for="star42">★</label>
            <input class="stel" type="radio" value="3" id="star32" name="valut2">
            <label class="stelabel" for="star32">★</label>
            <input class="stel" type="radio" value="2" id="star22" name="valut2">
            <label class="stelabel" for="star22">★</label>
            <input class="stel" type="radio" value="1" id="star12" name="valut2">
            <label class="stelabel" for="star12">★</label>
        </div>
        <div class="testofeedfo"> LIVELLO DI ANIMAZIONI : </div>
        <div class="stelvalf">
            <input class="stel" type="radio" value="5" id="star53" name="valut3">
            <label class="stelabel" for="star53">★</label>
            <input class="stel" type="radio" value="4" id="star43" name="valut3">
            <label class="stelabel" for="star43">★</label>
            <input class="stel" type="radio" value="3" id="star33" name="valut3">
            <label class="stelabel" for="star33">★</label>
            <input class="stel" type="radio" value="2" id="star23" name="valut3">
            <label class="stelabel" for="star23">★</label>
            <input class="stel" type="radio" value="1" id="star13" name="valut3">
            <label class="stelabel" for="star13">★</label>
        </div>
        <div class="testofeedfi"> LIVELLO DI FUNZIONAMENTO : </div>
        <div class="stelvalfi">
            <input class="stel" type="radio" value="5" id="star54" name="valut4">
            <label class="stelabel" for="star54">★</label>
            <input class="stel" type="radio" value="4" id="star44" name="valut4">
            <label class="stelabel" for="star44">★</label>
            <input class="stel" type="radio" value="3" id="star34" name="valut4">
            <label class="stelabel" for="star34">★</label>
            <input class="stel" type="radio" value="2" id="star24" name="valut4">
            <label class="stelabel" for="star24">★</label>
            <input class="stel" type="radio" value="1" id="star14" name="valut4">
            <label class="stelabel" for="star14">★</label>
        </div>
        <div class="testofeedult"> LIVELLO COMPLESSIVO : </div>
        <div class="stelvalult">
            <input class="stel" type="radio" value="5" id="star55" name="valut5">
            <label class="stelabel" for="star55">★</label>
            <input class="stel" type="radio" value="4" id="star45" name="valut5">
            <label class="stelabel" for="star45">★</label>
            <input class="stel" type="radio" value="3" id="star35" name="valut5">
            <label class="stelabel" for="star35">★</label>
            <input class="stel" type="radio" value="2" id="star25" name="valut5">
            <label class="stelabel" for="star25">★</label>
            <input class="stel" type="radio" value="1" id="star15" name="valut5">
            <label class="stelabel" for="star15">★</label>
        </div>
    </div>

    </body>

</html>