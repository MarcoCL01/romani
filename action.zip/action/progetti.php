<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> PROGETTI AZIENDALI </title>
    </head>
    
    <body class="background">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>

        <div class="containerprogo">
            <a href="progettouno.php"><img src="img\prog1.jpg" class="imageprogo"></a>
            <a href="progettodue.php"><img src="img\prog2.avif" class="imageprogo"></a>
        </div>
        <div class="containerprogt">
            <a href="progettotre.php"><img src="img\prog3.jpg" class="imageprogo"></a>
            <a href="progettoquattro.php"><img src="img\prog4.jpg" class="imageprogo"></a>
        </div>
        <div>
            <button id="feedback" class="feedback" onclick="location.href='feedback.php'"> FEEDBACK </button>
        </div>
    </body>
    
</html>