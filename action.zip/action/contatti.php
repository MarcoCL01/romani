<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> CONTATTI AZIENDALI </title>
    </head>
    
    <body class="background">
    <hr class="rigaconto">
    <hr class="rigacontt">
    <hr class="rigaconttt">
    <hr class="rigacontf">
    <hr class="rigacontff">
    <hr class="rigaconts">
    <div class="rigabsx">ROMANI&CO</div>
    <div class="rigabdx">ROMANI&CO</div>

    <div class="container">
    
    <img src="img\romani6.jpg" class="imagecon">

    <div class="textoverlayone"> CONTATTO TELEFONICO : <br>(+39) 3459738519 </div>
    
    <div class="textoverlaytwo"> CONTATTO EMAIL : marco.clerico45@gmail.com </div>
 
    <div class="textoverlaythree"> CONTATTO EMAIL-PEC :  marco.clerico45@pec.it </div>
    
    <div class="textoverlayfour"> INDIRIZZO SEDE : <br>Via Bergamotti 56 C, Ivrea(TO) </div>

    </div>

    <button type="submit" class="formcomp" id="formcomp" onclick="location.href='formcontatto.php'"> FORM DI CONTATTO </button>

    </body>
    
</html>