<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> PRODOTTO 1 </title>
    </head>
    
    <body class="background">
        <hr class="rigaone">
        <hr class="rigatwo">
        <hr class="rigathree">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>
        <div class="rigasxaz">ROMANI&CO</div>

        <div class="produd">
            <img src="img\elmu.jpg" class="imgprodu">
            <div class="tprodu">
                Un elmetto romano, noto come galea, era un copricapo in metallo progettato per proteggere i soldati in battaglia. 
                Solitamente realizzato in ferro o bronzo, aveva una forma arrotondata, protezioni per guance e collo, e spesso un rinforzo sulla sommità. 
                Poteva includere decorazioni o creste, soprattutto per i gradi più alti.
            </div>
        </div>

        <button class="btprodu"> Acquista ora </button>

    </body>
    
</html>