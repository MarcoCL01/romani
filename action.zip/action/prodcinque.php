<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> PRODOTTO 5 </title>
    </head>
    
    <body class="background">
        <hr class="rigaone">
        <hr class="rigatwo">
        <hr class="rigathree">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>
        <div class="rigasxaz">ROMANI&CO</div>

        <div class="produd">
            <img src="img\arco.webp" class="imgprodu">
            <div class="tprodu">
            L'arco romano era un'arma a distanza usata principalmente dagli arcieri ausiliari. 
            Realizzato in legno flessibile, spesso rinforzato con corno o tendini, era accompagnato da frecce con punte metalliche. 
            Leggero e versatile, serviva per colpire nemici a distanza con precisione.
            </div>
        </div>

        <button class="btprodu"> Acquista ora </button>
    </body>
    
</html>