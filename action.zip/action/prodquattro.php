<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> PRODOTTO 4 </title>
    </head>
    
    <body class="background">
        <hr class="rigaone">
        <hr class="rigatwo">
        <hr class="rigathree">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>
        <div class="rigasxaz">ROMANI&CO</div>

        <div class="produd">
            <img src="img\spada.jpg" class="imgprodu">
            <div class="tprodu">
            La spada romana, o gladio, era un'arma corta, a doppio taglio, ideale per colpire di punta o di taglio nei combattimenti ravvicinati. 
            Lunga circa 60-70 cm, con lama in acciaio e impugnatura in legno o osso, era utilizzata dai legionari come arma principale, efficace e maneggevole.
            </div>
        </div>

        <button class="btprodu"> Acquista ora </button>
        
    </body>
    
</html>