<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> PRODOTTO 6 </title>
    </head>
    
    <body class="background">
        <hr class="rigaone">
        <hr class="rigatwo">
        <hr class="rigathree">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>
        <div class="rigasxaz">ROMANI&CO</div>

        <div class="produd">
            <img src="img\balestra.webp" class="imgprodu">
            <div class="tprodu">
            La balestra romana, o arcuballista, era un'arma a distanza simile a un arco potenziato, montata su un telaio rigido. 
            Utilizzava meccanismi a torsione o leve per scagliare dardi con maggiore forza e precisione rispetto a un arco tradizionale. 
            Era usata sia in battaglia che negli assedi per colpire obiettivi lontani.
            </div>
        </div>

        <button class="btprodu"> Acquista ora </button>

    </body>
    
</html>