<!DOCTYPE html>
<html>
    
    <head>
        <link href="assets/css/style.css?version=1" rel="stylesheet" type="text/css">
        <title> PRODOTTO 3 </title>
    </head>
    
    <body class="background">
        <hr class="rigaone">
        <hr class="rigatwo">
        <hr class="rigathree">
        <hr class="rigafour">
        <hr class="rigafive">
        <hr class="rigasix">
        <div class="rigadxaz">ROMANI&CO</div>
        <div class="rigasxaz">ROMANI&CO</div>

        <div class="produd">
            <img src="img\scudo.jpg" class="imgprodu">
            <div class="tprodu">
            Lo scudo romano, o scutum, era un grande scudo rettangolare o ovale, curvato per proteggere meglio il corpo. 
            Realizzato in legno, rivestito di cuoio e rinforzato con metallo, serviva per difesa e per spingere i nemici, spesso decorato con simboli della legione di appartenenza.
            </div>
        </div>

        <button class="btprodu"> Acquista ora </button>
        
    </body>
    
</html>